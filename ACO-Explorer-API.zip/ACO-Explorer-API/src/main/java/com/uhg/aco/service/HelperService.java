package com.uhg.aco.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.uhg.aco.util.Constants;

@Service
public class HelperService {

	public long getCurrentUser() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof String) {
			String user = (String) principal;
			String[] data = user.split(Constants.SPECIAL_CHAR);
			if (data.length == 2)
				return Long.valueOf(data[1]);
			else
				return 0;
		} else {
			return 0;
		}
	}

	public long getCurrentUser(HttpServletRequest request) {
		return getCurrentUser();
	}

}
