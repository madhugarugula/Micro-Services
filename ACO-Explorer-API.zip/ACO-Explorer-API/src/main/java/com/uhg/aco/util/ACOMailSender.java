package com.uhg.aco.util;

import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

@Component
public class ACOMailSender {
	@Autowired
	private JavaMailSender javaMailSender;
	@Autowired
	private MessageConstants constants;
	private static final String CHARSET_UTF8 = "UTF-8";
	@Autowired
	private VelocityEngine velocityEngine;
	Logger LOG = LoggerFactory.getLogger(ACOMailSender.class);

	public void sendOTP(final String email, final String otp) {
		Map model = new HashMap<>();
		model.put("otp", otp);
		new Thread(new RunnableImpl(email, constants.otpMsg, model, "velocity/OnBoardOTPTemplate.vm")).start();
	}

	public void send(String to, String subject, Map model, String templateName) {
		MimeMessagePreparator preparator = new MimeMessagePreparator() {
			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {

				MimeMessageHelper message = new MimeMessageHelper(mimeMessage, MimeMessageHelper.MULTIPART_MODE_RELATED,
						"UTF-8");
				message.setFrom(new InternetAddress("lingarao.rajavarapu@xcubelabs.com"));
				message.setTo(to);
				message.setSubject(subject);

				message.setText(
						VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, templateName, CHARSET_UTF8, model),
						true);

			}
		};
		LOG.info("mail sending ++++++++++++++++++++++++++++++++" + to);
		this.javaMailSender.send(preparator);
		LOG.info("mail send ++++++++++++++++++++++++++++++++" + to);
	}

	public class RunnableImpl implements Runnable {

		private String to;
		private String subject;
		private String template;
		private Map model;

		/**
		*
		*/
		public RunnableImpl(String to, String subject, Map model, String template) {
			this.to = to;
			this.subject = subject;
			this.model = model;
			this.template = template;
		}

		@Override
		public void run() {
			LOG.info("RunnableImpl++++++++++++++++++++++++++++++++" + to);
			send(to, subject, model, template);
		}

	}
}
