package com.uhg.aco.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class MessageConstants {

	@Value(value = "${OTPExpiredTime}")
	public String OTPExpiredTime;

	@Value(value = "${otpMsg}")
	public String otpMsg;

	@Value(value = "${contributorNotExist}")
	public String contributorNotExist;

	@Value(value = "${otpVerificationfail}")
	public String otpVerificationfail;

	@Value(value = "${OTPNotExist}")
	public String OTPNotExist;
	
	@Value(value = "${AcoNotFound}")
	public String AcoNotFound;

}
