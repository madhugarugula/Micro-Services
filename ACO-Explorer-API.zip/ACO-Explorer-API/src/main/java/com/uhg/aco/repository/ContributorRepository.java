package com.uhg.aco.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.uhg.aco.core.Contributor;

public interface ContributorRepository extends PagingAndSortingRepository<Contributor, Long> {

	Contributor findByEmail(@Param(value = "email") String email);

}
