package com.uhg.aco.aws;

import java.io.InputStream;

public class PutObjectData {

	private InputStream inputFile;
	private String filename;
	private int fileSize;
	private String fileToWrite;
	private int widthToCompress;
	private int heightToCompress;
	private String position;

	/**
	 * @return the position
	 */
	public String getPosition() {
		return position;
	}

	public PutObjectData(InputStream inputFile, int fileSize) {
		super();
		this.inputFile = inputFile;
		this.fileSize = fileSize;

	}

	public PutObjectData(InputStream inputFile, String bucketName, int IMG_WIDTH, int IMG_HEIGHT, String filetowrite,
			String position, String filename) {
		super();

		this.inputFile = inputFile;
		this.fileToWrite = filetowrite;
		this.widthToCompress = IMG_WIDTH;
		this.heightToCompress = IMG_HEIGHT;
		this.position = position;
		this.filename = filename;

	}

	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename
	 *            the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

	/**
	 * @return the fileToWrite
	 */
	public String getFileToWrite() {
		return fileToWrite;
	}

	/**
	 * @return the widthToCompress
	 */
	public int getWidthToCompress() {
		return widthToCompress;
	}

	/**
	 * @return the heightToCompress
	 */
	public int getHeightToCompress() {
		return heightToCompress;
	}

	/**
	 * @return the inputFile
	 */
	public InputStream getInputFile() {
		return inputFile;
	}

	/**
	 * @param inputFile
	 *            the inputFile to set
	 */
	public void setInputFile(InputStream inputFile) {
		this.inputFile = inputFile;
	}

	/**
	 * @return the fileSize
	 */
	public int getFileSize() {
		return fileSize;
	}

	/**
	 * @param fileSize
	 *            the fileSize to set
	 */
	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}

}
