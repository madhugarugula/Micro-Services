
package com.uhg.aco.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.uhg.aco.core.ACOStructure;
import com.uhg.aco.core.Aco;
import com.uhg.aco.core.EMR;

public class AcoInputVo {

	private long id;

	private String name;
	private int ei;
	private int mr;
	private int cs;
	private Date activationDate;
	private Date createdDate;
	private int noOfProviders;
	private int noOfClinicSite;
	private long structure;
	private int certification;
	private long emr;
	private int hie;
	private int patientPortal;
	private List<ParticipantInputVo> participants = new ArrayList<ParticipantInputVo>();
	private List<ContributorInputVo> contributors = new ArrayList<ContributorInputVo>();

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEi() {
		return ei;
	}

	public void setEi(int ei) {
		this.ei = ei;
	}

	public int getMr() {
		return mr;
	}

	public void setMr(int mr) {
		this.mr = mr;
	}

	public int getCs() {
		return cs;
	}

	public void setCs(int cs) {
		this.cs = cs;
	}

	public Date getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getNoOfProviders() {
		return noOfProviders;
	}

	public void setNoOfProviders(int noOfProviders) {
		this.noOfProviders = noOfProviders;
	}

	public int getNoOfClinicSite() {
		return noOfClinicSite;
	}

	public void setNoOfClinicSite(int noOfClinicSite) {
		this.noOfClinicSite = noOfClinicSite;
	}

	public long getStructure() {
		return structure;
	}

	public void setStructure(long structure) {
		this.structure = structure;
	}

	public long getEmr() {
		return emr;
	}

	public void setEmr(long emr) {
		this.emr = emr;
	}

	public List<ParticipantInputVo> getParticipants() {
		return participants;
	}

	public void setParticipants(List<ParticipantInputVo> participants) {
		this.participants = participants;
	}

	public List<ContributorInputVo> getContributors() {
		return contributors;
	}

	public void setContributors(List<ContributorInputVo> contributors) {
		this.contributors = contributors;
	}

	public Aco toAco() {
		Aco aco = new Aco();
		aco.setId(id);
		aco.setName(name);
		aco.setEi(ei);
		aco.setMr(mr);
		aco.setCs(cs);
		aco.setActivationDate(activationDate);
		aco.setNoOfProviders(noOfProviders);
		aco.setNoOfClinicSite(noOfClinicSite);
		if (structure != 0) {
			aco.setStructure(new ACOStructure(structure));
		}
		aco.setCertification(getCertification());
		if (emr != 0) {
			aco.setEmr(new EMR(emr));
		}
		aco.setHie(getHie());
		aco.setPatientPortal(getPatientPortal());
		aco.setParticipants(participants.stream().map(participantInputVo -> participantInputVo.toParticipant())
				.collect(Collectors.toList()));
		aco.setContributors(contributors.stream().map(contributorInputVo -> contributorInputVo.toContributor())
				.collect(Collectors.toList()));

		return aco;
	}

	public Boolean getCertification() {
		if (certification == -1) {
			return null;
		}
		if (certification == 1) {
			return true;
		}
		return false;
	}

	public void setCertification(int certification) {
		this.certification = certification;
	}

	public Boolean getHie() {
		if (hie == -1) {
			return null;
		}
		if (hie == 1) {
			return true;
		}
		return false;
	}

	public void setHie(int hie) {
		this.hie = hie;
	}

	public Boolean getPatientPortal() {
		if (patientPortal == -1) {
			return null;
		}
		if (patientPortal == 1) {
			return true;
		}
		return false;
	}

	public void setPatientPortal(int patientPortal) {
		this.patientPortal = patientPortal;
	}
}
