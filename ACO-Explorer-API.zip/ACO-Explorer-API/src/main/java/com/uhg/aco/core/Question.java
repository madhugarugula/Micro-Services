package com.uhg.aco.core;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class Question extends CreatableObject {

	private static final long serialVersionUID = 1L;

	private String name;

	private String description;

	private String aliasName;

	@ManyToOne
	private Question parent;

	/**
	 * all options are concatenation by comma
	 */
	private String options;

	private boolean active;

	@ManyToOne
	private QuestionCategory category;

	public Question() {

	}

	public Question(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Question getParent() {
		return parent;
	}

	public void setParent(Question parent) {
		this.parent = parent;
	}

	public String getOptions() {
		return options;
	}

	public void setOptions(String options) {
		this.options = options;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public QuestionCategory getCategory() {
		return category;
	}

	public void setCategory(QuestionCategory category) {
		this.category = category;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

}
