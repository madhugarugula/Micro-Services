package com.uhg.aco.vo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.uhg.aco.core.Question;
import com.uhg.aco.core.Role;
import com.uhg.aco.core.RoleQuestion;

public class QuestionsByRoleResponseVo {

	private long roleId;

	private List<QuestionVo> questions = new ArrayList<>();

	public QuestionsByRoleResponseVo(Role role) {
		this.setRoleId(role.getId());
		List<RoleQuestion> roleQuestions = role.getQuestions();
		setQuestions(IntStream.range(0, roleQuestions.size())
				.mapToObj(index -> createQuestionVo(index, roleQuestions.get(index))).collect(Collectors.toList()));
	}

	private QuestionVo createQuestionVo(int index, RoleQuestion roleQuestion) {
		Question question = roleQuestion.getQuestion();
		QuestionVo questionVo = new QuestionVo();
		questionVo.setId(question.getId());
		questionVo.setPriority(roleQuestion.isPriority());
		questionVo.setName(question.getName());
		questionVo.setCategory(question.getCategory().getName());
		questionVo.setDescription(question.getDescription());
		questionVo.setIndex(index);
		List<SubQuestionVo> subquestions = new ArrayList<>();
		Question parent = question.getParent();
		subquestions.add(new SubQuestionVo(parent));
		subquestions.add(new SubQuestionVo(parent.getParent()));
		questionVo.setSubquestions(subquestions);
		return questionVo;
	}

	create(int index,Question question,subquestions){
		if()
		
	}
	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public List<QuestionVo> getQuestions() {
		return questions;
	}

	public void setQuestions(List<QuestionVo> questions) {
		this.questions = questions;
	}

}
