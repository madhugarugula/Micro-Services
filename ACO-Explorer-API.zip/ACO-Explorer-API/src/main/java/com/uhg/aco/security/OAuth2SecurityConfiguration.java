package com.uhg.aco.security;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.oauth2.config.annotation.builders.InMemoryClientDetailsServiceBuilder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;

@Configuration
@EnableAuthorizationServer
public class OAuth2SecurityConfiguration extends AuthorizationServerConfigurerAdapter {

	@Autowired
	@Qualifier("authenticationManagerBeen")
	private AuthenticationManager authenticationManager;

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private JwtAccessTokenConverter converter;

	@Value(value = "${access_token_expire_time}")
	public int accessTokenExpireTime;

	@Value(value = "${refresh_token_expire_time}")
	public int refreshTokenExpireTime;

	@Autowired
	private TokenStore tokenStore;

	@Autowired
	private Environment env;

	@Override
	public void configure(AuthorizationServerSecurityConfigurer security) throws Exception {
		security.tokenKeyAccess("permitAll()");
		security.checkTokenAccess("permitAll()");
	}

	@Override
	public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
		endpoints.allowedTokenEndpointRequestMethods(HttpMethod.GET, HttpMethod.POST);
		endpoints.tokenStore(tokenStore).authenticationManager(this.authenticationManager)
				.userDetailsService(userDetailsService).accessTokenConverter(converter);
	}

	@Override
	public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
		InMemoryClientDetailsServiceBuilder inMemory = clients.inMemory();
		inMemory.withClient(env.getProperty("security.uaa.client_id"))
				.authorizedGrantTypes("password", "refresh_token", "client_credentials").authorities("USER")
				.scopes("read", "write")
				.secret(new String(Base64.getDecoder().decode(env.getProperty("security.uaa.client_secret"))))
				.accessTokenValiditySeconds(accessTokenExpireTime).refreshTokenValiditySeconds(refreshTokenExpireTime);
	}

	@Bean
	public JwtAccessTokenConverter accessTokenConverter(@Value("${security.jwt.signing.key}") String signingKey) {
		JwtAccessTokenConverter converter = new JwtAccessTokenConverter();
		converter.setSigningKey(new String(Base64.getDecoder().decode(signingKey)));
		return converter;
	}

	@Bean
	public JwtTokenStore tokenStore(JwtAccessTokenConverter converter) {
		return new JwtTokenStore(converter);
	}
}
