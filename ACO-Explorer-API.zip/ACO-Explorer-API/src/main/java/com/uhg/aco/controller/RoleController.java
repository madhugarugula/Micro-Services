package com.uhg.aco.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.uhg.aco.core.Role;
import com.uhg.aco.repository.RoleRepository;
import com.uhg.aco.vo.QuestionsByRoleReqVo;
import com.uhg.aco.vo.QuestionsByRoleResponseVo;

@Controller
@RequestMapping("api/v1/security/role")
public class RoleController {

	@Autowired
	RoleRepository roleRepository;

	@RequestMapping(value = "/questions", method = RequestMethod.POST)
	public ResponseEntity<BaseResponse> getQuestions(@RequestBody QuestionsByRoleReqVo questionsByRoleReqVo) {
		BaseResponse response = new BaseResponse();
		response.setStatus(HttpStatus.OK);
		response.setMessage("Success");
		Role role = roleRepository.findOne(questionsByRoleReqVo.getRole());
		response.setData(new QuestionsByRoleResponseVo(role));
		return new ResponseEntity<BaseResponse>(response, HttpStatus.OK);
	}

}
