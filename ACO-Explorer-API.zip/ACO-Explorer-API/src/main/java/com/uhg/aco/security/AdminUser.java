package com.uhg.aco.security;

import org.springframework.security.core.authority.AuthorityUtils;

public class AdminUser extends org.springframework.security.core.userdetails.User {

    private static final long serialVersionUID = 1L;

    private Long user;

    public AdminUser(String email, String password, long id) {
        super(email, password, AuthorityUtils.createAuthorityList("USER"));
        this.user = id;
    }

    public Long getId() {
        return user;
    }

    public void setId(Long id) {
        this.user = id;
    }

}
