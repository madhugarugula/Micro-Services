package com.uhg.aco.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.uhg.aco.core.Aco;

public class AcoVo {

	private String name;
	private Date date;
	private List<String> contributors = new ArrayList<>();
	private long id;

	public AcoVo(Aco aco) {
		setId(aco.getId());
		setDate(aco.getCreatedDate());
		setContributors(aco.getContributors().stream()
				.map(contributor -> contributor.getFirstName() + " " + contributor.getLastName())
				.collect(Collectors.toList()));
		setName(aco.getName());
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static List<AcoVo> fromList(List<Aco> states) {
		List<AcoVo> vos = new ArrayList<>();
		for (Aco s : states) {
			vos.add(new AcoVo(s));
		}
		return vos;
	}

	public List<String> getContributors() {
		return contributors;
	}

	public void setContributors(List<String> contributors) {
		this.contributors = contributors;
	}
}
