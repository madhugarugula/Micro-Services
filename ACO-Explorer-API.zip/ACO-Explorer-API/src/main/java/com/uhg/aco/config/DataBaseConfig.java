/**
 * @author pushpalatha, 16-Sep-2016
 */
package com.uhg.aco.config;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * This class is useful to establish connection with User Data Base Server.
 *
 * @author pushpalatha
 */
@Configuration
@EnableTransactionManagement
public class DataBaseConfig {

	/**
	 * User database session factory.
	 *
	 * @return LocalSessionFactoryBean
	 */

	@Bean

	@ConfigurationProperties(prefix = "spring.datasource")
	public DataSource dataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
		sessionFactoryBean.setDataSource(dataSource());
		sessionFactoryBean.setPackagesToScan("com.wasel");
		return sessionFactoryBean;
	}

	/**
	 * User database transaction manager.
	 *
	 * @return HibernateTransactionManager
	 */
	@Bean
	public HibernateTransactionManager transactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(sessionFactory().getObject());
		return transactionManager;
	}

} // class DatabaseConfig
