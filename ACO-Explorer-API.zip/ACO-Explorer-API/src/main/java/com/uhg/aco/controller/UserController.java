package com.uhg.aco.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.uhg.aco.core.User;
import com.uhg.aco.repository.UserRepository;
import com.uhg.aco.vo.UserInfo;
import com.uhg.aco.vo.UserVo;

@Controller
@RequestMapping("api/v1/security/user")

public class UserController {

	private Logger LOG = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserRepository userRepository;

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ResponseEntity<BaseResponse> updateUser(@RequestBody UserVo userVo) {
		BaseResponse response = new BaseResponse();
		User user = userRepository.getOne(userVo.getId());
		user.setFirstname(userVo.getFirstname());
		user.setLastname(userVo.getLastname());
		user.setTitle(userVo.getTitle());
		user = userRepository.save(user);
		response.setStatus(HttpStatus.OK);
		response.setMessage("Success");
		response.setData(new UserInfo(user));
		return new ResponseEntity<BaseResponse>(response, HttpStatus.OK);
	}

}
