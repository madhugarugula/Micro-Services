package com.uhg.aco.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.uhg.aco.core.ACOStructure;

public interface ACOStructureRepository extends PagingAndSortingRepository<ACOStructure, Long> {

}
