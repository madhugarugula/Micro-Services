package com.uhg.aco.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.uhg.aco.core.Participant;

public interface ParticipantRepository extends PagingAndSortingRepository<Participant, Long> {

	@Query("from Participant p  where p.parent.id=:acoId ")
	List<Participant> findAllByAco(@Param("acoId") long acoId);

}
