package com.uhg.aco.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;

public class BaseResponse {

	private int status = 200;
	private String message;
	private Map<String, String> error = new HashMap<>();
	private Object data;

	public int getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status.value();
	}

	public Map<String, String> getError() {
		return error;
	}

	public void setError(Map<String, String> error) {
		this.error = error;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public void setMessage(String s) {
		this.message = s;
	}

	public String getMessage() {
		return message;
	}

	public void setStatus(int status) {
		this.status = status;
	}

}
