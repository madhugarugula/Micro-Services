package com.uhg.aco.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uhg.aco.core.Contributor;
import com.uhg.aco.repository.ContributorRepository;
import com.uhg.aco.vo.ContributorVo;

@RequestMapping("/contributor")
public class ContributorController {

	Logger LOG = LoggerFactory.getLogger(AcoController.class);

	@Autowired
	private ContributorRepository contributorRepository;

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<BaseResponse> save(@RequestBody Contributor aco) {
		BaseResponse response = new BaseResponse();
		Contributor save = contributorRepository.save(aco);
		response.setStatus(HttpStatus.OK);
		response.setMessage("Success");
		response.setData(new ContributorVo(save));
		return new ResponseEntity<BaseResponse>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/list}", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<BaseResponse> list() {
		BaseResponse response = new BaseResponse();
		response.setStatus(HttpStatus.OK);
		response.setMessage("Success");
		response.setData(ContributorVo.fromList(contributorRepository.findAll()));
		return new ResponseEntity<BaseResponse>(response, HttpStatus.OK);
	}

}
