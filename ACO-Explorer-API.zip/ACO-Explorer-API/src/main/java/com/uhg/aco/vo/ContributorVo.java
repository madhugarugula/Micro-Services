package com.uhg.aco.vo;

import java.util.ArrayList;
import java.util.List;

import com.uhg.aco.core.Contributor;

public class ContributorVo {

	public ContributorVo(Contributor save) {
		// TODO Auto-generated constructor stub
	}

	public static List<ContributorVo> fromList(Iterable<Contributor> contributors) {
		List<ContributorVo> vos = new ArrayList<>();
		for (Contributor s : contributors) {
			vos.add(new ContributorVo(s));
		}
		return vos;
	}

}
