package com.uhg.aco.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.uhg.aco.core.Question;

public interface QuestionRepository extends PagingAndSortingRepository<Question, Long> {

}
