package com.uhg.aco.vo;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.uhg.aco.core.Participant;

public class ParticipantVo {

	private Date date;

	//private Time time;

	private String firstName;

	private String lastName;

	private String location;

	public ParticipantVo(Participant participant) {
		setDate(participant.getDate());
		// TODO set Time
		setFirstName(participant.getFirstName());
		setLastName(participant.getLastName());
		setLocation(participant.getLocation());
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

//	public Time getTime() {
//		return time;
//	}
//
//	public void setTime(Time time) {
//		this.time = time;
//	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public static Object fromList(List<Participant> participants) {
		List<ParticipantVo> vos = new ArrayList<>();
		for (Participant s : participants) {
			vos.add(new ParticipantVo(s));
		}
		return vos;
	}
}
