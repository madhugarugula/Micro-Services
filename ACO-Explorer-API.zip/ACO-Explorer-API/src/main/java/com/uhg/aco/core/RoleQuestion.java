package com.uhg.aco.core;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class RoleQuestion implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	private Question question;

	@ManyToOne
	@JoinColumn(name = "parent_id", nullable = false)
	private Role role;

	private boolean isPriority;

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public boolean isPriority() {
		return isPriority;
	}

	public void setPriority(boolean isPriority) {
		this.isPriority = isPriority;
	}

}
