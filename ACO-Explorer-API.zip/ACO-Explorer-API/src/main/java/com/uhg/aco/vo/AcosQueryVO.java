package com.uhg.aco.vo;

public class AcosQueryVO extends PageInfo {

	private boolean sharedGuides;

	public boolean isSharedGuides() {
		return sharedGuides;
	}

	public void setSharedGuides(boolean sharedGuides) {
		this.sharedGuides = sharedGuides;
	}

}
