package com.uhg.aco.controller;

import java.time.LocalDateTime;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.uhg.aco.core.Otp;
import com.uhg.aco.core.User;
import com.uhg.aco.repository.OTPRepository;
import com.uhg.aco.repository.UserRepository;
import com.uhg.aco.security.AccessTokenGenerator;
import com.uhg.aco.util.ACOMailSender;
import com.uhg.aco.util.MessageConstants;
import com.uhg.aco.vo.LoginInfo;
import com.uhg.aco.vo.UserInfo;

@Controller
@RequestMapping("api/v1/public")
public class LoginController {

	private Logger LOG = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private OTPRepository otpRepository;

	@Autowired
	private MessageConstants constants;

	@Autowired
	private AccessTokenGenerator tokenGenerator;

	@Autowired
	private ACOMailSender mailSender;

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<Object> login(@RequestBody LoginInfo loginInfo) {
		BaseResponse response = new BaseResponse();
		String email = loginInfo.getEmail();
		User user = userRepository.findByEmail(email);
		if (user == null) {
			user = new User();
			user.setEmail(email);
		}

		String generatedOtp = UUID.randomUUID().toString().substring(0, 8).toLowerCase();
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		// Saving User
		user.setPassword(passwordEncoder.encode(generatedOtp));
		user = userRepository.save(user);
		// Saving OTP
		Otp otp = otpRepository.findByUserId(user.getId());
		if (otp == null) {
			otp = new Otp(passwordEncoder.encode(generatedOtp), user.getId());
		} else {
			otp.setOtp(passwordEncoder.encode(generatedOtp));
			otp.setActive(true);
			otp.setCreatedDate(LocalDateTime.now());
		}
		otpRepository.save(otp);

		LOG.info("=============>OTP: " + generatedOtp);
		mailSender.sendOTP(email, generatedOtp);
		response.setStatus(HttpStatus.OK);
		response.setMessage("Sucess");
		response.setData(generatedOtp);
		return new ResponseEntity<Object>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/verifyOtp", method = RequestMethod.POST)
	public ResponseEntity<Object> verifyOtp(@RequestBody LoginInfo loginInfo) {
		BaseResponse response = new BaseResponse();
		String email = loginInfo.getEmail();
		String userOTP = loginInfo.getOtp();
		if (userOTP == null || userOTP.isEmpty()) {
			LOG.info("otp not present");
			response.setStatus(HttpStatus.EXPECTATION_FAILED);
			response.setMessage(constants.OTPNotExist);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		}
		User user = userRepository.findByEmail(email);
		Otp otp = otpRepository.findByUserId(user.getId());
		boolean isValid = vaidateOTPTime(otp);
		if (!isValid) {
			response.setStatus(HttpStatus.EXPECTATION_FAILED);
			response.setMessage(constants.otpVerificationfail);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		}
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		boolean matches = passwordEncoder.matches(userOTP, otp.getOtp());
		LOG.info("is password matches>>" + matches);
		if (!matches) {
			response.setStatus(HttpStatus.EXPECTATION_FAILED);
			response.setMessage(constants.OTPNotExist);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		}
		// Making OTP InActive
		otp.setActive(false);
		otpRepository.save(otp);
		// Generating Oauth token
		OAuth2AccessToken oauthToken = tokenGenerator.generateOauthTokens(loginInfo);
		// Response
		response.setStatus(HttpStatus.OK);
		response.setMessage("Success");
		response.setData(new UserInfo(user, oauthToken));
		return new ResponseEntity<Object>(response, HttpStatus.OK);
	}

	/**
	 * Validate OTP time
	 * 
	 * @param otp
	 * @return
	 */
	private boolean vaidateOTPTime(Otp otp) {
		LocalDateTime localtDateAndTime = LocalDateTime.now();
		LocalDateTime localDateAndTimeOfgeneratedOTP = otp.getCreatedDate();
		localDateAndTimeOfgeneratedOTP = localDateAndTimeOfgeneratedOTP
				.plusMinutes(Integer.parseInt(constants.OTPExpiredTime));
		LOG.info("localDateAndTimeOfgeneratedOTP after miniute plus>>" + localDateAndTimeOfgeneratedOTP
				+ "localtDateAndTime>>" + localtDateAndTime);
		LOG.info("time compare return" + localDateAndTimeOfgeneratedOTP.compareTo(localtDateAndTime));
		return localDateAndTimeOfgeneratedOTP.compareTo(localtDateAndTime) > 0;

	}
}
