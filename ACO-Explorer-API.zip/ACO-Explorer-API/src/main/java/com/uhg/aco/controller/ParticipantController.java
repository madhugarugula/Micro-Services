package com.uhg.aco.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uhg.aco.repository.ParticipantRepository;
import com.uhg.aco.vo.ParticipantVo;
import com.uhg.aco.vo.ParticipantsByAcoQueryInfo;

@Controller
@RequestMapping("api/v1/security/participant")
public class ParticipantController {

	private Logger LOG = LoggerFactory.getLogger(AcoController.class);

	@Autowired
	private ParticipantRepository participantRepository;

	@RequestMapping(value = "/list", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<BaseResponse> list(@RequestBody ParticipantsByAcoQueryInfo queryVO) {
		LOG.info("Getting Participants by ACO");
		PageRequest page = new PageRequest(queryVO.getPage(), queryVO.getSize(), Direction.ASC, "id");
		BaseResponse response = new BaseResponse();
		response.setStatus(HttpStatus.OK);
		response.setMessage("Success");
		response.setData(ParticipantVo.fromList(participantRepository.findAllByAco(queryVO.getGuideId())));
		return new ResponseEntity<BaseResponse>(response, HttpStatus.OK);
	}

}
