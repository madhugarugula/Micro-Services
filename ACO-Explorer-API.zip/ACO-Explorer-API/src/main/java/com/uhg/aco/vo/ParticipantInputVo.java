package com.uhg.aco.vo;

import java.util.Date;

import com.uhg.aco.core.Participant;
import com.uhg.aco.core.Role;

public class ParticipantInputVo {

	private long id;

	private String firstName;
	private String lastName;
	private String orgName;
	private String title;
	private long role;
	private Date date;
	private String location;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public long getRole() {
		return role;
	}

	public void setRole(long role) {
		this.role = role;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Participant toParticipant() {
		Participant participant = new Participant();
		participant.setId(id);
		participant.setFirstName(firstName);
		participant.setLastName(lastName);
		participant.setTitle(title);
		participant.setLocation(location);
		participant.setOrgName(orgName);
		participant.setDate(date);
		if (role != 0) {
			participant.setRole(new Role(role));
		}
		return participant;
	}
}
