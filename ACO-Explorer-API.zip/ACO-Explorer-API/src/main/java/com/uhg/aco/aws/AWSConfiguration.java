package com.uhg.aco.aws;

import java.io.File;
import java.io.InputStream;

import org.apache.log4j.Logger;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;

public class AWSConfiguration {
	Logger LOGGER = Logger.getLogger(AWSConfiguration.class);
	private AmazonS3 amazonS3;

	private String accessKey;

	private String secretKey;

	public AWSConfiguration(String accessKey, String secretKey, String bucketName) {
		super();
		this.accessKey = accessKey;
		this.secretKey = secretKey;
		this.bucketName = bucketName;
		getS3Instance();
	}

	public String bucketName;

	/**
	 * Initialize amazon client
	 * 
	 * @version V.1.0.0.0
	 */

	private void getS3Instance() {
		amazonS3 = new AmazonS3Client(new BasicAWSCredentials(accessKey, secretKey));
	}

	/**
	 * Store the file into a bucket on S3
	 * 
	 * @param strBucketName
	 * 
	 * @param key
	 *            the filename used to store
	 * 
	 * @param file
	 *            the file to be stored.
	 * 
	 */
	public String getFileUrl(GeneratePresignedUrlRequest req) {
		return amazonS3.generatePresignedUrl(req) + "";
	}

	public void storeDataInS3(String strBucketName, String key, File file) {
		PutObjectRequest por = new PutObjectRequest(strBucketName, key, file);
		por.setCannedAcl(CannedAccessControlList.PublicRead);
		amazonS3.putObject(por);
	}

	public String storeDataInS3(String strBucketName, String key, InputStream inputStream, long length) {
		ObjectMetadata metadata = new ObjectMetadata();

		PutObjectRequest por = new PutObjectRequest(strBucketName, key, inputStream, metadata);
		por.setCannedAcl(CannedAccessControlList.PublicRead);
		LOGGER.info("*******************************storeDataInS3********* putObject ********Start*************"
				+ amazonS3);
		PutObjectResult result = amazonS3.putObject(por);
		LOGGER.info("*******************************storeDataInS3********* putObject ********End*************");
		return result.getETag();
	}

	public void removeData(String bucketName, String key) {

		amazonS3.deleteObject(bucketName, key);
	}

	public void removeDataFromSubBucket(String subBucketName, String strFileName, String key) {
		String fileKey = subBucketName + "/" + strFileName;
		removeData(bucketName, fileKey);
	}

	public String storeDataInS3SubBucket(String subBucketName, String strFileName, File file) {
		String fileKey = subBucketName + "/" + strFileName;
		storeDataInS3(bucketName, fileKey, file);
		return fileKey;
	}

	public String storeDataInS3SubBucket(String subBucketName, String strFileName, InputStream inputStream,
			long length) {
		String fileKey = subBucketName + "/" + strFileName;
		return storeDataInS3(bucketName, fileKey, inputStream, length);
	}
}
