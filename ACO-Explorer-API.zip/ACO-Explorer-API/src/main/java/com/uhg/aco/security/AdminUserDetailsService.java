package com.uhg.aco.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.stereotype.Service;

import com.uhg.aco.core.User;
import com.uhg.aco.repository.UserRepository;
import com.uhg.aco.util.Constants;

@Service("userDetailsService")
public class AdminUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRepository repository;

	@Autowired
	private ClientDetailsService parent;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = null;
		String[] data = username.split(Constants.SPECIAL_CHAR);
		if (data.length == 2) {
			username = data[1];
			user = repository.findOne(Long.parseLong(username));
		} else {
			user = repository.findByEmail(username);
		}
		if (user == null) {
			ClientDetails client = parent.loadClientByClientId(username);
			return new org.springframework.security.core.userdetails.User(client.getClientId(),
					new BCryptPasswordEncoder().encode(client.getClientSecret()), client.getAuthorities());
		}
		return new AdminUser(username + Constants.SPECIAL_CHAR + user.getId(), user.getPassword(), user.getId());
	}
}
