package com.uhg.aco.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.uhg.aco.core.EMR;

public interface EMRRepository extends PagingAndSortingRepository<EMR, Long> {

}
