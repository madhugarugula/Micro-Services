package com.uhg.aco.vo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.uhg.aco.core.Question;

public class SubQuestionVo {

	private long id;

	private String name;

	private String description;

	private List<String> options = new ArrayList<>();

	public SubQuestionVo(Question parent) {
		setId(parent.getId());
		setName(parent.getName());
		setDescription(parent.getDescription());
		setOptions(Arrays.asList(parent.getOptions().split(",")));
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<String> getOptions() {
		return options;
	}

	public void setOptions(List<String> options) {
		this.options = options;
	}

}
