package com.uhg.aco.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.uhg.aco.core.Otp;

public interface OTPRepository extends CrudRepository<Otp, Long> {

	Otp findByUserId(@Param(value = "userId") long userId);

}
