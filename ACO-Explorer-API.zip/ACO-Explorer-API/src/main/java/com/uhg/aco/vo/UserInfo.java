package com.uhg.aco.vo;

import org.springframework.security.oauth2.common.OAuth2AccessToken;

import com.uhg.aco.core.User;

public class UserInfo {
	private long id;
	private String accessToken;
	private String refreshToken;
	private String email;
	private String firstname;
	private String lastname;
	private String title;

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public UserInfo(User user, OAuth2AccessToken oauthToken) {
		setId(user.getId());
		setAccessToken(oauthToken.getValue());
		setRefreshToken(oauthToken.getRefreshToken().getValue());
		setFirstname(user.getFirstname());
		setLastname(user.getLastname());
		setTitle(user.getTitle());
		setEmail(user.getEmail());
	}

	public UserInfo(User user) {
		setId(user.getId());
		setFirstname(user.getFirstname());
		setLastname(user.getLastname());
		setTitle(user.getTitle());
		setEmail(user.getEmail());
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
