package com.uhg.aco.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.uhg.aco.core.Aco;

public interface AcoRepository extends PagingAndSortingRepository<Aco, Long> {

	@Query("from Aco aco left join fetch aco.contributors con where con.userId=:userId")
	List<Aco> getSharedGuides(@Param("userId") long userId);

	@Query("from Aco aco  where aco.createdBy=:userId ")
	List<Aco> getMyGuides(@Param("userId") long userId);

}
