package com.uhg.aco.util;

public interface Constants {

	String SPECIAL_CHAR = "Ð";

}
