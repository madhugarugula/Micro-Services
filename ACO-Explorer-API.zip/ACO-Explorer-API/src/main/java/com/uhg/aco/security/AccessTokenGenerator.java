package com.uhg.aco.security;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.endpoint.TokenEndpoint;
import org.springframework.stereotype.Component;

import com.uhg.aco.vo.LoginInfo;

@Component
public class AccessTokenGenerator {

	private static final Logger LOG = LoggerFactory.getLogger(AccessTokenGenerator.class);

	@Autowired
	private TokenEndpoint endpoint;

	@Autowired
	private Environment env;

	@Autowired
	private AuthenticationManager authenticationManager;

	public OAuth2AccessToken generateOauthTokens(LoginInfo info) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("username", info.getEmail());
		params.put("password", info.getOtp());
		params.put("grant_type", "password");
		UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(
				env.getProperty("security.uaa.client_id"),
				new String(Base64.getDecoder().decode(env.getProperty("security.uaa.client_secret")))) {
			private static final long serialVersionUID = 1L;

			@Override
			public boolean isAuthenticated() {
				return true;
			}
		};
		try {
			Authentication authResult = this.authenticationManager.authenticate(authRequest);
			SecurityContextHolder.getContext().setAuthentication(authResult);
			ResponseEntity<OAuth2AccessToken> token = endpoint.postAccessToken(authRequest, params);
			return token.getBody();
		} catch (Exception e) {
			LOG.error("", e);
		}
		return null;
	}
}
