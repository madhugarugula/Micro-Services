package com.uhg.aco.vo;

import com.uhg.aco.core.Contributor;

public class ContributorInputVo {

	private long id;

	private String firstName;
	private String lastName;
	private String email;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Contributor toContributor() {
		Contributor contributor = new Contributor();
		contributor.setId(id);
		contributor.setFirstName(firstName);
		contributor.setLastName(lastName);
		contributor.setEmail(email);
		return contributor;
	}

}
