package com.uhg.aco.aws;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PutObjectReq {

	PutObjectData putObjectData;

	@Value(value = "${cloud.aws.credentials.secretKey}")
	private String secretKey;

	@Value(value = "${cloud.aws.credentials.accessKey}")
	private String accessKey;

	@Value(value = "${cloud.aws.s3.bucket}")
	public String bucketName;

	/**
	 * @return the accessKey
	 */
	public String getAccessKey() {
		return accessKey;
	}

	/**
	 * @param accessKey
	 *            the accessKey to set
	 */
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	/**
	 * @return the secretKey
	 */
	public String getSecretKey() {
		return secretKey;
	}

	/**
	 * @param secretKey
	 *            the secretKey to set
	 */
	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	/**
	 * @return the bucketName
	 */
	public String getBucketName() {
		return bucketName;
	}

	/**
	 * @param bucketName
	 *            the bucketName to set
	 */
	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}

	/**
	 * @param putObjectData
	 *            the putObjectData to set
	 */
	public void setPutObjectData(PutObjectData putObjectData) {
		this.putObjectData = putObjectData;
	}

	/**
	 * @return the putObjectData
	 */
	public PutObjectData getPutObjectData() {
		return putObjectData;
	}

}
