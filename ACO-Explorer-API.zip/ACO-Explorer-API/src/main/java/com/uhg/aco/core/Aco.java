package com.uhg.aco.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_aco")
public class Aco extends CreatableObject {

	private static final long serialVersionUID = 1L;
	private String name;
	private int ei;
	private int mr;
	private int cs;
	private Date activationDate;
	private int noOfProviders;
	private int noOfClinicSite;
	@ManyToOne
	private ACOStructure structure;
	private Boolean certification;
	@ManyToOne
	private EMR emr;
	private Boolean hie;
	private Boolean patientPortal;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "parent")
	private List<Participant> participants = new ArrayList<>();

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "parent")
	private List<Contributor> contributors = new ArrayList<>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEi() {
		return ei;
	}

	public void setEi(int ei) {
		this.ei = ei;
	}

	public int getMr() {
		return mr;
	}

	public void setMr(int mr) {
		this.mr = mr;
	}

	public int getCs() {
		return cs;
	}

	public void setCs(int cs) {
		this.cs = cs;
	}

	public Date getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}

	public int getNoOfProviders() {
		return noOfProviders;
	}

	public void setNoOfProviders(int noOfProviders) {
		this.noOfProviders = noOfProviders;
	}

	public int getNoOfClinicSite() {
		return noOfClinicSite;
	}

	public void setNoOfClinicSite(int noOfClinicSite) {
		this.noOfClinicSite = noOfClinicSite;
	}

	public ACOStructure getStructure() {
		return structure;
	}

	public void setStructure(ACOStructure structure) {
		this.structure = structure;
	}

	public EMR getEmr() {
		return emr;
	}

	public void setEmr(EMR emr) {
		this.emr = emr;
	}

	public Boolean isPatientPortal() {
		return patientPortal;
	}

	public void setPatientPortal(Boolean patientPortal) {
		this.patientPortal = patientPortal;
	}

	public List<Participant> getParticipants() {
		return participants;
	}

	public void setParticipants(List<Participant> participants) {
		this.participants = participants;
	}

	public List<Contributor> getContributors() {
		return contributors;
	}

	public void setContributors(List<Contributor> contributors) {
		this.contributors = contributors;
	}

	public Boolean isCertification() {
		return certification;
	}

	public void setCertification(Boolean certification) {
		this.certification = certification;
	}

	public Boolean isHie() {
		return hie;
	}

	public void setHie(Boolean hie) {
		this.hie = hie;
	}

}
