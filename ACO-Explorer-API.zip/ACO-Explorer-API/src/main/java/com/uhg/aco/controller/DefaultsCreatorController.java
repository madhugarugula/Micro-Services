package com.uhg.aco.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.uhg.aco.core.ACOStructure;
import com.uhg.aco.core.EMR;
import com.uhg.aco.core.Question;
import com.uhg.aco.core.QuestionCategory;
import com.uhg.aco.core.Role;
import com.uhg.aco.core.RoleQuestion;
import com.uhg.aco.repository.ACOStructureRepository;
import com.uhg.aco.repository.EMRRepository;
import com.uhg.aco.repository.QuestionCategoryReposoitory;
import com.uhg.aco.repository.QuestionRepository;
import com.uhg.aco.repository.RoleRepository;

import scala.annotation.

strictfp;

@Controller public class DefaultsCreatorController {

	@Autowired
	private ACOStructureRepository acoStructureRepository;

	@Autowired
	private EMRRepository emrRepository;

	@Autowired
	private QuestionRepository questionRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	QuestionCategoryReposoitory questionCategoryReposoitory;

	Map<String, QuestionCategory> categoriesByName = new HashMap<String, QuestionCategory>();

	@RequestMapping(value = "/default", method = RequestMethod.GET)
	public void createDefaults() {

		// ACOStructure's
		List<ACOStructure> acoStructures = new ArrayList<ACOStructure>();
		acoStructures.add(new ACOStructure("IPA (Independent Physicians Association)"));
		acoStructures.add(new ACOStructure("Hospital Based – Centralized"));
		acoStructures.add(new ACOStructure("Hospital Based –Distributed "));
		acoStructures.add(new ACOStructure("Physician Group Based – Centralized"));
		acoStructures.add(new ACOStructure("Physician Group Based – Distributed"));
		acoStructures.add(new ACOStructure("University Based – Centralized"));
		acoStructures.add(new ACOStructure("University Based – Distributed"));
		acoStructures.add(new ACOStructure("Other (write in)"));
		acoStructureRepository.save(acoStructures);

		// EMR's
		List<EMR> emrs = new ArrayList<EMR>();
		emrs.add(new EMR("Single EHR across ACO"));
		emrs.add(new EMR("Multiple EHR(s)"));
		emrs.add(new EMR("No EHR"));
		emrRepository.save(emrs);

		Iterable<QuestionCategory> categories = questionCategoryReposoitory.save(createQuestionCategories());
		// map.get(categories.iterator().next());

		for (QuestionCategory questionCategory : categories) {
			categoriesByName.put(questionCategory.getName(), questionCategory);
		}

		/// questions:
		questionRepository.save(createQuestions());

		// Role's
		roleRepository.save(createRoles());

	}

	private List<QuestionCategory> createQuestionCategories() {
		List<QuestionCategory> questionCategories = new ArrayList<>();
		// questionCategory1
		QuestionCategory questionCategory = new QuestionCategory();
		questionCategory.setName("Role and Staff Structure");

		// questionCategory2
		QuestionCategory questionCategory2 = new QuestionCategory();
		questionCategory2.setName("Process");

		// questionCategory3
		QuestionCategory questionCategory3 = new QuestionCategory();
		questionCategory3.setName("Data Use");

		// questionCategory4
		QuestionCategory questionCategory4 = new QuestionCategory();
		questionCategory4.setName("Programs");

		// questionCategory5
		QuestionCategory questionCategory5 = new QuestionCategory();
		questionCategory5.setName("Patient Engagement");

		// questionCategory6
		QuestionCategory questionCategory6 = new QuestionCategory();
		questionCategory6.setName("Care Coordination");

		questionCategories.add(questionCategory);
		questionCategories.add(questionCategory2);
		questionCategories.add(questionCategory3);
		questionCategories.add(questionCategory4);
		questionCategories.add(questionCategory5);
		questionCategories.add(questionCategory6);
		return questionCategories;
	}

	private List<Role> createRoles() {
		List<Role> roles = new ArrayList<>();
		// Role1
		Role role = new Role();
		role.setName("ACO Executive");
		// Role2
		Role role2 = new Role();
		role2.setName("ACO Leadership");
		// Role3
		Role role3 = new Role();
		role3.setName(" Practice Leadership");
		// Role4
		Role role4 = new Role();
		role4.setName("Care Manager");
		// Role5
		Role role5 = new Role();
		role5.setName("Practice Front Line Staff");
		// Role6
		Role role6 = new Role();
		role6.setName("IT/Analytics");

		// adding the role to list
		roles.add(role);
		roles.add(role2);
		roles.add(role3);
		roles.add(role4);
		roles.add(role4);
		roles.add(role5);
		roles.add(role6);

		List<RoleQuestion> questions = new ArrayList<>();
		RoleQuestion question = new RoleQuestion();
		question.setPriority(true);

		// question.setQuestion(question);
		questions.add(question);
		role.setQuestions(questions);

		// TODO creating Question categories

		// Role's
		// roleRepository.save(createRoles());

		return roles;
	}

	private List<Question> createQuestions() {
		List<Question> questions = new ArrayList<>();
		// Question1
		Question question = new Question();
		// TODO set all property values
		question.setName("Describe the relationship between the ACO and the practices sites.");
		question.setDescription("Give an example of how you work together.");
		question.setAliasName("ACO/Practice Relationship");
		question.setParent(question.getParent());
		question.setOptions("");
		question.setActive(true);
		question.setCategory(categoriesByName.get("Role and Staff Structure"));
		questions.add(question);

		// Question2
		Question question2 = new Question();
		// TODO set all property values
		question2.setName("Describe who you work with frequently. What does your work relationship look like?");
		question2.setDescription("How often are you able to collaborate at work?");
		question2.setAliasName("TeamWork");
		question2.setParent(question.getParent());
		question2.setOptions("");
		question2.setActive(true);
		question2.setCategory(categoriesByName.get("Role and Staff Structure"));
		questions.add(question2);

		// Question3
		Question question3 = new Question();
		// TODO set all property values
		question3.setName("Describe your role and key responsibilities.");
		question3.setDescription("Do you ever take on responsibilities beyond your role?");
		question3.setAliasName("Job Description and Responsibilities");
		question3.setParent(question.getParent());
		question3.setOptions("");
		question3.setActive(true);
		question3.setCategory(categoriesByName.get("Role and Staff Structure"));
		questions.add(question3);

		// Question4
		Question question4 = new Question();
		// TODO set all property values
		question4.setName(
				"What type of information is communicated between the ACO and practice sites? How often is it share?");
		question4.setDescription("What gets in the way of sharing information?");
		question4.setAliasName("Communication");
		question4.setParent(question.getParent());
		question4.setOptions("");
		question4.setActive(true);
		question4.setCategory(categoriesByName.get("Role and Staff Structure"));
		questions.add(question4);

		// Question5
		Question question5 = new Question();
		// TODO set all property values
		question5.setName(
				"What is your understanding of the ACO’s goals for this year? What does success of those goals look like?");
		question5.setDescription("What motivates you to achieve those goals?");
		question5.setAliasName("Motivation");
		question5.setParent(question.getParent());
		question5.setOptions("");
		question5.setActive(true);
		question5.setCategory(categoriesByName.get("Role and Staff Structure"));
		questions.add(question5);

		// Question6
		Question question6 = new Question();
		// TODO set all property values
		question6.setName("Describe how new processes and procedures are created.");
		question6.setDescription(
				"Give us an example of a process that have been put in place. Who was involved/ included?");
		question6.setAliasName("Motivation");
		question6.setParent(question.getParent());
		question6.setOptions("");
		question6.setActive(true);
		question6.setCategory(categoriesByName.get("Process"));
		questions.add(question6);

		// Question7
		Question question7 = new Question();
		// TODO set all property values
		question7.setName("Can you describe the level of detail and structure that tends to go into a given process?");
		question7.setDescription("What do you tend to document? In what form?");
		question7.setAliasName("Motivation");
		question7.setParent(question.getParent());
		question7.setOptions("");
		question7.setActive(true);
		question7.setCategory(categoriesByName.get("Process"));
		questions.add(question7);

		// Question8
		Question question8 = new Question();
		// TODO set all property values
		question8.setName("How are processes documented and shared?");
		question8.setDescription("Who are processes shared with? Who is included/ excluded?");
		question8.setAliasName("Motivation");
		question8.setParent(question.getParent());
		question8.setOptions("");
		question8.setActive(true);
		question8.setCategory(categoriesByName.get("Process"));
		questions.add(question8);

		// Question9
		Question question9 = new Question();
		// TODO set all property values
		question9.setName("Walk us through using a typical process or procedure. How did it go?");
		question9.setDescription("How useful was the process for accomplishing the task.");
		question9.setAliasName("Motivation");
		question9.setParent(question.getParent());
		question9.setOptions("");
		question9.setActive(true);
		question9.setCategory(categoriesByName.get("Process"));
		questions.add(question9);

		// Question10
		Question question10 = new Question();
		// TODO set all property values
		question10.setName("Describe your ability to adjust or make changes to a process.");
		question10.setDescription("How flexible are the processes?");
		question10.setAliasName("Motivation");
		question10.setParent(question.getParent());
		question10.setOptions("");
		question10.setActive(true);
		question10.setCategory(categoriesByName.get("Process"));
		questions.add(question10);

		// Question11
		Question question11 = new Question();
		// TODO set all property values
		question11.setName("What sort of data do you have access to? What form is it in?");
		question11.setDescription("How do you use the data?");
		question11.setAliasName("Motivation");
		question11.setParent(question.getParent());
		question11.setOptions("");
		question11.setActive(true);
		question11.setCategory(categoriesByName.get("Data Use"));
		questions.add(question11);

		// Question12
		Question question12 = new Question();
		// TODO set all property values
		question12.setName("How is data exchanged within the ACO and practice sites? How frequently?.");
		question12.setDescription("Do the systems currently in place support information and data exchange?");
		question12.setAliasName("Motivation");
		question12.setParent(question.getParent());
		question12.setOptions("");
		question12.setActive(true);
		question12.setCategory(categoriesByName.get("Data Use"));
		questions.add(question12);

		// Question13
		Question question13 = new Question();
		// TODO set all property values
		question13.setName("What form is the data in? How do you interpret it?");
		question13.setDescription("What resources and expertise to you have in place to interpret data?");
		question13.setAliasName("Motivation");
		question13.setParent(question.getParent());
		question13.setOptions("");
		question13.setActive(true);
		question13.setCategory(categoriesByName.get("Data Use"));
		questions.add(question13);

		// Question14
		Question question14 = new Question();
		// TODO set all property values
		question14.setName("What data is most useful to you? What is least useful?");
		question14.setDescription("What are the barriers to receiving and sharing information?");
		question14.setAliasName("Motivation");
		question14.setParent(question.getParent());
		question14.setOptions("");
		question14.setActive(true);
		question14.setCategory(categoriesByName.get("Data Use"));
		questions.add(question14);

		// Question15
		Question question15 = new Question();
		// TODO set all property values
		question15.setName("Describe how using data fits into your day.");
		question15.setDescription("How often do they use data in their work?");
		question15.setAliasName("Motivation");
		question15.setParent(question.getParent());
		question15.setOptions("");
		question15.setActive(true);
		question15.setCategory(categoriesByName.get("Data Use"));
		questions.add(question15);

		// Question16
		Question question16 = new Question();
		// TODO set all property values
		question16.setName("What offerings such as services, classes and programs, are available to your patients?");
		question16.setDescription("Are the programs offered ACO-wide or specific to practice sites?");
		question16.setAliasName("Motivation");
		question16.setParent(question.getParent());
		question16.setOptions("");
		question16.setActive(true);
		question16.setCategory(categoriesByName.get("Programs"));
		questions.add(question16);

		// Question17
		Question question17 = new Question();
		// TODO set all property values
		question17.setName("What patient needs do the programs available address? How tailored are they?");
		question17.setDescription("What programs do you feel are still missing or that you hope to add?");
		question17.setAliasName("Motivation");
		question17.setParent(question.getParent());
		question17.setOptions("");
		question17.setActive(true);
		question17.setCategory(categoriesByName.get("Programs"));
		questions.add(question17);

		// Question18
		Question question18 = new Question();
		// TODO set all property values
		question18.setName("What training and education is provided for those who run various programs?");
		question18.setDescription("Are you aware of any additional education sources outside of what is provided?");
		question18.setAliasName("Motivation");
		question18.setParent(question.getParent());
		question18.setOptions("");
		question18.setActive(true);
		question18.setCategory(categoriesByName.get("Programs"));
		questions.add(question18);

		// Question19
		Question question19 = new Question();
		// TODO set all property values
		question19.setName("How do patients tend to learn about the programs offered?");
		question19.setDescription("Which patients are offered programs?");
		question19.setAliasName("Motivation");
		question19.setParent(question.getParent());
		question19.setOptions("");
		question19.setActive(true);
		question19.setCategory(categoriesByName.get("Programs"));
		questions.add(question19);

		// Question20
		Question question20 = new Question();
		// TODO set all property values
		question20.setName("What programs are the most successful? Why?");
		question20.setDescription("Tell us about who tend to participate, and to what degree?");
		question20.setAliasName("Motivation");
		question20.setParent(question.getParent());
		question20.setOptions("");
		question20.setActive(true);
		question20.setCategory(categoriesByName.get("Programs"));
		questions.add(question20);

		// Question21
		Question question21 = new Question();
		// TODO set all property values
		question21.setName("How would you describe your patient population?");
		question21.setDescription("How do you determine which population(s) to focus on?");
		question21.setAliasName("Motivation");
		question21.setParent(question.getParent());
		question21.setOptions("");
		question21.setActive(true);
		question21.setCategory(categoriesByName.get("Patient Engagement"));
		questions.add(question21);

		// Question22
		Question question22 = new Question();
		// TODO set all property values
		question22.setName(
				"What factors in a patient’s life do you consider in order to deliver the best possible care?");
		question22.setDescription("What patient context information would you like to have better insight into?");
		question22.setAliasName("Motivation");
		question22.setParent(question.getParent());
		question22.setOptions("");
		question22.setActive(true);
		question22.setCategory(categoriesByName.get("Patient Engagement"));
		questions.add(question22);

		// Question23
		Question question23 = new Question();
		// TODO set all property values
		question23.setName("Can you share some examples of how you tend to do patient outreach?");
		question23.setDescription(
				"Does outreach take place at ACO or practice site level? Do you use any external resources?");
		question23.setAliasName("Motivation");
		question23.setParent(question.getParent());
		question23.setOptions("");
		question23.setActive(true);
		question23.setCategory(categoriesByName.get("Patient Engagement"));
		questions.add(question23);

		// Question24
		Question question24 = new Question();
		// TODO set all property values
		question24.setName("What extended access options do you have available for your patients?");
		question24.setDescription("What are the most common barriers for patient access?");
		question21.setAliasName("Motivation");
		question24.setParent(question.getParent());
		question24.setOptions("");
		question24.setActive(true);
		question24.setCategory(categoriesByName.get("Patient Engagement"));
		questions.add(question24);

		// Question25
		Question question25 = new Question();
		// TODO set all property values
		question25.setName("How involved are your patients in their care?");
		question25.setDescription("Do you have any efforts in place to encourage patient participation?");
		question25.setAliasName("Motivation");
		question25.setParent(question.getParent());
		question25.setOptions("");
		question25.setActive(true);
		question25.setCategory(categoriesByName.get("Patient Engagement"));
		questions.add(question21);

		// Question26
		Question question26 = new Question();
		// TODO set all property values
		question26.setName("Describe your process for care coordination.");
		question26.setDescription("How is you care coordination staff situated? Within the ACO or practice site?");
		question26.setAliasName("Motivation");
		question26.setParent(question.getParent());
		question26.setOptions("");
		question26.setActive(true);
		question26.setCategory(categoriesByName.get("Care Coordination"));
		questions.add(question21);

		// Question27
		Question question27 = new Question();
		// TODO set all property values
		question27.setName("Describe the type of patients included in care coordination.");
		question27.setDescription("Describe you patient inclusion criteria or stratification.");
		question27.setAliasName("Motivation");
		question27.setParent(question.getParent());
		question27.setOptions("");
		question27.setActive(true);
		question27.setCategory(categoriesByName.get("Care Coordination"));
		questions.add(question27);

		// Question28
		Question question28 = new Question();
		// TODO set all property values
		question28.setName("How does case management factor into your approach?");
		question28.setDescription("What resources do you have available to you for case management?");
		question28.setAliasName("Motivation");
		question28.setParent(question.getParent());
		question28.setOptions("");
		question28.setActive(true);
		question28.setCategory(categoriesByName.get("Care Coordination"));
		questions.add(question28);

		// Question29
		Question question29 = new Question();
		// TODO set all property values
		question29.setName("Describe a relationship with a patient involved in care coordination.");
		question29.setDescription("Which role is most involved with maintaining the patient relationship");
		question29.setAliasName("Motivation");
		question29.setParent(question.getParent());
		question29.setOptions("");
		question29.setActive(true);
		question29.setCategory(categoriesByName.get("Care Coordination"));
		questions.add(question29);

		// Question30
		Question question30 = new Question();
		// TODO set all property values
		question30.setName("What patient information do you find useful in care coordination?");
		question30.setDescription("How do you gather, document, and share contextual information?");
		question30.setAliasName("Motivation");
		question30.setParent(question.getParent());
		question30.setOptions("");
		question30.setActive(true);
		question30.setCategory(categoriesByName.get("Care Coordination"));
		questions.add(question30);
		return questions;
	}

}
