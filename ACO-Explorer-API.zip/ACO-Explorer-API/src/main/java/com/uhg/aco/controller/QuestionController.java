package com.uhg.aco.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uhg.aco.vo.AcoInputVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping("api/v1/security/questions")
@Api(value = "Questions")

public class QuestionController {

	private Logger LOG = LoggerFactory.getLogger(QuestionController.class);

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	@ApiOperation(value = "save", notes = "This will allow you to save questions.", response = BaseResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success.") })
	public @ResponseBody ResponseEntity<BaseResponse> save(@RequestBody AcoInputVo acoInputVo) {
		BaseResponse response = new BaseResponse();
		response.setStatus(HttpStatus.OK);
		response.setMessage("Success");
		return new ResponseEntity<BaseResponse>(response, HttpStatus.OK);

	}
}
