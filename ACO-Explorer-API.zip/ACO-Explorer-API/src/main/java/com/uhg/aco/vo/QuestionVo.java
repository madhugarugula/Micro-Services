package com.uhg.aco.vo;

import java.util.ArrayList;
import java.util.List;

import com.uhg.aco.core.Question;

public class QuestionVo {

	private long id;

	private boolean isPriority;

	private String name;

	private String category;

	private String description;

	private int index;

	private List<SubQuestionVo> subquestions = new ArrayList<>();

	public QuestionVo(Question parent) {
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public boolean isPriority() {
		return isPriority;
	}

	public void setPriority(boolean isPriority) {
		this.isPriority = isPriority;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public List<SubQuestionVo> getSubquestions() {
		return subquestions;
	}

	public void setSubquestions(List<SubQuestionVo> subquestions) {
		this.subquestions = subquestions;
	}

}
