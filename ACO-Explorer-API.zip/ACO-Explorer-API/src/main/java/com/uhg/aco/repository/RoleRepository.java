package com.uhg.aco.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.uhg.aco.core.Role;

public interface RoleRepository extends PagingAndSortingRepository<Role, Long> {

}
