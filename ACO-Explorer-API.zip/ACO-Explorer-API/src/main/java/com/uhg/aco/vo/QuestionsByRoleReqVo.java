package com.uhg.aco.vo;

public class QuestionsByRoleReqVo {

	private long role;

	public long getRole() {
		return role;
	}

	public void setRole(long role) {
		this.role = role;
	}

}
