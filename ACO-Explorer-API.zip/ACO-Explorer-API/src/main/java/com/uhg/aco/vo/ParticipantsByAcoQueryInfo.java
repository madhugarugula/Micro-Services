package com.uhg.aco.vo;

public class ParticipantsByAcoQueryInfo extends PageInfo {

	private long guideId;

	public long getGuideId() {
		return guideId;
	}

	public void setGuideId(long guideId) {
		this.guideId = guideId;
	}

}
