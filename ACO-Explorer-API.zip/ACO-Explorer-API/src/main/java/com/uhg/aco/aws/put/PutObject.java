package com.uhg.aco.aws.put;

import java.io.InputStream;
import java.util.UUID;
import java.util.logging.Logger;

import com.uhg.aco.aws.AWSConfiguration;
import com.uhg.aco.aws.PutObjectData;
import com.uhg.aco.aws.PutObjectReq;

public class PutObject {
	private static final Logger LOGGER = Logger.getLogger(PutObject.class.getName());

	public String objectToPut(PutObjectReq putObjectReq) {
		PutObjectData putObjectData = putObjectReq.getPutObjectData();
		int fileSize = putObjectData.getFileSize();
		InputStream inputStream = putObjectData.getInputFile();

		String bucketName = putObjectReq.getBucketName();
		String accessKey = putObjectReq.getAccessKey();
		String secretKey = putObjectReq.getSecretKey();
		String fileName = UUID.randomUUID().toString();

		AWSConfiguration aswConf = new AWSConfiguration(accessKey, secretKey, bucketName);

		aswConf.storeDataInS3(bucketName, fileName, inputStream, fileSize);
		return fileName;

	}

}
