package com.uhg.aco.vo;

import java.util.Date;
import java.util.stream.Collectors;

import com.uhg.aco.core.Aco;

public class AcoOutputVo extends AcoInputVo {
	

	public static AcoOutputVo convertACOToAcoInputVo(Aco aco) {
		AcoOutputVo acoVo = new AcoOutputVo();
		acoVo.setId(aco.getId());
		acoVo.setName(aco.getName());
		acoVo.setEi(aco.getEi());
		acoVo.setMr(aco.getMr());
		acoVo.setCs(aco.getCs());
		acoVo.setActivationDate(aco.getActivationDate());
		acoVo.setCreatedDate(aco.getCreatedDate());
		acoVo.setNoOfProviders(aco.getNoOfProviders());
		acoVo.setNoOfClinicSite(aco.getNoOfClinicSite());
		if (aco.getStructure() != null) {
			acoVo.setStructure(aco.getStructure().getId());
		}
		acoVo.setCertification(aco.isCertification() == null ? -1 : aco.isCertification() ? 1 : -1);
		if (aco.getEmr() != null) {
			acoVo.setEmr(aco.getEmr().getId());
		}
		acoVo.setHie(aco.isHie() == null ? -1 : aco.isHie() ? 1 : -1);
		acoVo.setPatientPortal(aco.isPatientPortal() == null ? -1 : aco.isPatientPortal() ? 1 : -1);
		acoVo.setParticipants(aco.getParticipants().stream().map(p -> {
			ParticipantInputVo pio = new ParticipantInputVo();
			pio.setDate(p.getDate());
			pio.setFirstName(p.getFirstName());
			pio.setId(p.getId());
			pio.setLastName(p.getLastName());
			pio.setLocation(p.getLocation());
			if (p.getRole() != null) {
				pio.setRole(p.getRole().getId());
			}
			pio.setTitle(p.getTitle());
			pio.setOrgName(p.getOrgName());
			return pio;
		}).collect(Collectors.toList()));
		acoVo.setContributors(aco.getContributors().stream().map(c -> {
			ContributorInputVo cvo = new ContributorInputVo();
			cvo.setId(c.getId());
			cvo.setEmail(c.getEmail());
			cvo.setFirstName(c.getFirstName());
			cvo.setLastName(c.getLastName());
			return cvo;
		}).collect(Collectors.toList()));

		return acoVo;
	}
}
