package com.uhg.aco.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uhg.aco.core.Aco;
import com.uhg.aco.core.User;
import com.uhg.aco.repository.AcoRepository;
import com.uhg.aco.repository.UserRepository;
import com.uhg.aco.service.HelperService;
import com.uhg.aco.util.MessageConstants;
import com.uhg.aco.vo.AcoInputVo;
import com.uhg.aco.vo.AcoOutputVo;
import com.uhg.aco.vo.AcoVo;
import com.uhg.aco.vo.AcosQueryVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Controller
@RequestMapping("api/v1/security/aco")
@Api(value = "Guide")
public class AcoController {

	private Logger LOG = LoggerFactory.getLogger(AcoController.class);

	@Autowired
	HelperService helperService;

	@Autowired
	private AcoRepository acoRepository;

	@Autowired
	private MessageConstants constants;

	@Autowired
	UserRepository userRepository;

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	@ApiOperation(value = "save", notes = "This will allow you to save guide(ACO).", response = BaseResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success.") })
	public @ResponseBody ResponseEntity<BaseResponse> save(@RequestBody AcoInputVo acoInputVo) {
		BaseResponse response = new BaseResponse();
		Aco aco = acoInputVo.toAco();
		// Setting parent to Child's
		aco.getContributors().forEach(contributor -> {
			contributor.setParent(aco);
			User user = userRepository.findByEmail(contributor.getEmail());
			if (user == null) {
				user = new User();
				user.setEmail(contributor.getEmail());
			}
			user = userRepository.save(user);
			contributor.setUserId(user.getId());
		});
		aco.getParticipants().forEach(contributor -> contributor.setParent(aco));
		aco.setCreatedBy(helperService.getCurrentUser());
		aco.setModifiedBy(helperService.getCurrentUser());
		Aco save = acoRepository.save(aco);
		response.setStatus(HttpStatus.OK);
		response.setMessage("Success");
		response.setData(AcoOutputVo.convertACOToAcoInputVo(save));
		return new ResponseEntity<BaseResponse>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/list", method = RequestMethod.POST)
	@ApiOperation(value = "list", notes = "This will allow you to get guides(ACOs).", response = BaseResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success.") })
	public @ResponseBody ResponseEntity<BaseResponse> list(@RequestBody AcosQueryVO queryVO) {
		PageRequest page = new PageRequest(queryVO.getPage(), queryVO.getSize(), Direction.ASC, "createdDate");
		BaseResponse response = new BaseResponse();
		if (queryVO.isSharedGuides()) {
			response.setData(AcoVo.fromList(acoRepository.getSharedGuides(helperService.getCurrentUser())));
		} else {
			response.setData(AcoVo.fromList(acoRepository.getMyGuides(helperService.getCurrentUser())));
		}
		response.setStatus(HttpStatus.OK);
		response.setMessage("Success");
		return new ResponseEntity<BaseResponse>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/get/{id}", method = RequestMethod.GET)
	@ApiOperation(value = "list", notes = "This will allow you to get guide by id.", response = BaseResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success.") })
	public @ResponseBody ResponseEntity<BaseResponse> get(@PathVariable("id") long id) {
		BaseResponse response = new BaseResponse();
		Aco aco = acoRepository.findOne(id);
		if (aco == null) {
			response.setStatus(HttpStatus.NOT_FOUND);
			response.setMessage(constants.AcoNotFound);
			return new ResponseEntity<BaseResponse>(response, HttpStatus.OK);
		}
		AcoOutputVo acoInputVo = AcoOutputVo.convertACOToAcoInputVo(aco);
		response.setData(acoInputVo);
		response.setStatus(HttpStatus.OK);
		response.setMessage("Success");
		return new ResponseEntity<BaseResponse>(response, HttpStatus.OK);
	}
}
