package com.uhg.aco.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfiguration {
	@Bean
	public Docket swaggerSettings() {
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.uhg.aco.controller")).paths(PathSelectors.any()).build()
				.apiInfo(new ApiInfo("ACO-Explorer API(s)", "ACO-Explorer API Request and Response formats, All api(s) "
						+ "implemented based on Bearer authentication " + "i.e) OAuth2 except Authentication api(s). "
						+ "Sample request header <b>Authorization: Bearer {accessToken}</b>. "
						+ "You will get accessToken on response of login & signup api(s).", "0.0.1", null,
						"lingarao.rajavarapu@xcubelabs.com", null, null))
				.useDefaultResponseMessages(false).pathMapping("/");
	}
}