#!/bin/bash

/home/gitlab-runner/pmd-bin-5.6.0/bin/run.sh pmd -f text  -R ~/ruleset.xml -language java -d src/main/java/ 
if [ $? == 0 ]; then 
    /home/gitlab-runner/pmd-bin-5.6.0/bin/run.sh cpd --minimum-tokens 50 --files src/main/java/  --format text 
    if [ $? ==  0 ]; then 
        mvn clean;
        mvn package;
        exit $?;
    fi 
fi
exit -1;

