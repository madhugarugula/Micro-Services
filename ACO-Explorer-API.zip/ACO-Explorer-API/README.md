# Test

# Spring Best Practice #

This document describes the best practices following while developing spring application at PurpleTalk environment.

## Define singleton beans with names same as their class or interface names ##

Most of the bean definitions in Spring ApplicationContext are singleton scope, and again they are mostly sole bean definitions of their classes in the application. Developers therefore, give them names same as with their class or interface names in order to easily match with bean definitions with their classes. That way, it becomes easier to go from beans to their classes or vice versa.

public class SecurityServiceImpl implements SecurityService {
 
    @Override
    public String getCurrentUser() {
        //...
    }
}
<bean id="securityService" class="com.example.service.SecurityServiceImpl">
.....
</bean>

## Place Spring bean configuration files under a folder instead of root folder ##

If you place xml configuration files under root class path, and create a jar then, Spring might fail to discover those xml bean configuration files within jar file, if they are loaded with wildcards like below.


<web-app>
 <context-param>
 <param-name>contextConfigLocation</param-name>
 <param-value>classpath*:/beans-*.xml</param-value>
</context-param>
</web-app>


This problem is related with a limitation of Java IO API, and it is better to create a folder such as /beans or /appcontext and place xml configuration files beneath it. That way, it becomes safe to employ wildcards while loading them from jar archives.

## Give common prefixes or suffixes to Spring bean configuration files ##
